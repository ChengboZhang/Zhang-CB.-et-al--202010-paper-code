#中国地图
library(maptools)
library(sp)
library(sf)
china_map <- rgdal::readOGR('ori_data/China//bou2_4p.shp')
head(fortify(china_map))
chinmap = fortify(china_map)
head(chinmap)
p = ggplot()+geom_polygon(data = chinmap,aes(x=long,y=lat,group=group),colour='grey',fill = "grey80")+#,fill = group
  scale_fill_discrete(guide = FALSE)
nine <- sf::st_read('ori_data/add_map//国界九段线.shp')
nine
p
p1 = p +geom_sf(data = nine,aes( geometry = `geometry`),color = "grey30")
p1
northear <- sf::st_read('ori_data/add_map//南海诸岛.shp')
p2 = p1 +geom_sf(data = northear,aes( geometry = `geometry`),color = "grey30")
p2
#加坐标点
zb <- read.csv("zb.csv", header = T)
head(zb)
attach(zb)
#出图
q <- p2 + geom_point(data = zb, aes(x=long, y=lat, col="black"))
q

#百度地图画地图

library(devtools)
library(usethis)
install_github("badbye/baidumap")
install_github("lchiffon/REmap")

library(baidumap)
library(REmap)
library(ggmap)
library(ggplot2)

#设置百度地图密钥
options(baidumap.key="8AZUHUbwGLdrn3XHQkSGV7UEaiGkRHNq")
#画出北京地图
p <- getBaiduMap(c(lon=116.354431, lat=39.942333))
ggmap(p)

#画出野象谷地图
p <- getBaiduMap(c(lon=100.858164, lat=22.172967))
ggmap(p)
#缩放大小
p1 <- getBaiduMap(c(lon=100.858164, lat=22.172967), width=250, height=250, zoom = 14)
ggmap(p1)

#根据地址获取经纬度
getCoordinate("云南西双版纳国家自然保护区亚洲象野外研究基地", formatted = T)


##多样性小提琴图
setwd("C:/Dell/R/Data")
shannon <- read.delim("C:/Dell/R/Data/alpha.txt")
head(shannon)
library(ggplot2)
p <- ggplot(shannon, aes(x=group, y=chao, color=group))+geom_violin(trim=FALSE)
p
p1 <- p + geom_boxplot(width=0.1) 
p1
my_comparisons <- list(c("JY", "YS"))

p2 <-p1+stat_compare_means(comparisons = my_comparisons) + stat_compare_means(label.y = 1700)
p2
p2 + geom_jitter(shape=16, position=position_jitter(0.2))+theme_classic()


shannon <- read.delim("C:/Dell/R/Data/algorithm.txt")
head(shannon)
library(ggplot2)
p <- ggplot(shannon, aes(x=algorithm, y=error, color=algorithm))+geom_boxplot()
p
p+stat_summary(fun.y=mean, geom="point", shape=16, size=4)+theme_classic()


#叠装图
# 安装和加载tidyverse包
install.packages("tidyverse")
library(tidyverse)
# 生成测试数据
df=data.frame(
  Phylum=c("Firmicutes","Bacteroidetes","Spirochaetae","Verrucomicrobia","Fibrobacteres","Proteobacteria","Synergistetes","others"),
  JY=c(45.6822,31.4129,7.7504,4.9204,4.1324,1.9007,1.3346,2.8664),
  YS=c(43.3787,28.5906,9.9809,9.0199,4.4379,1.3453,0.3185,2.9283)
)

# 计算连线起始点Y轴坐标，即累计丰度的值
link_dat <- df %>% 
  arrange(by=desc(Phylum)) %>% 
  mutate(JY=cumsum(JY), YS=cumsum(YS)) 

# 数据格式转换，宽表格转换为ggplot2使用的长表格
df.long <- df %>% gather(group, abundance, -Phylum)
## 或者使用reshape2的melt函数
## df.long <- reshape2::melt(df, value.name='abundance', variable.name='group')

# 绘图，堆叠柱状图+组间连线
ggplot(df.long, aes(x=group, y=abundance, fill=Phylum)) + 
  geom_bar(stat = "identity", width=0.5, col='black')  + 
  geom_segment(data=link_dat, aes(x=1.25, xend=1.75, y=JY, yend=YS))
