

#清空工作目录#
rm(list = ls())
#设置工作目录#
setwd("C:/Dell/R/Data")

#数据读入#
w=read.csv("otu.csv",header = T)
head(w[1:5,1:5])
w=w[,-1]
w[,1]=factor(w[,1])

Z=3;##5折
T=2;##Group有2个水平
n=nrow(w)
e=names(table(w$Group))
d=1:n;
dd=list()##列表保存不同Group样本

for(i in 1:2){
    dd[[i]]=d[w[,1]==e[i]]
}
dd  #将2个分组的样本列好展示在列表里

kk=NULL
for(i in 1:T){
  kk=c(kk,round(length(dd[[i]])/Z))
       }
kk##kk[i]表示第i类中没折的数目

set.seed(111)
yy=list(NULL,NULL)

for(i in 1:T){
  xx=list()
  uu=dd[[i]]
  for(j in 1:(Z-1)){
    xx[[j]]=sample(uu,kk[[i]])
    uu=setdiff(uu,xx[[j]])#uu有而xx[[j]]没有的值。这个循环相当于无重复随机抽样。
  }
  xx[[Z]]=uu##多余的放在最后
  for(k in 1:Z){
    yy[[i]][[k]]=xx[[k]]
  }
}

yy

mm=list(NULL,NULL,NULL)
for(i in 1:Z){
  for(j in 1:T){
    mm[[i]]=c(mm[[i]],yy[[j]][[i]])
    }
  }
mm



#决策树的3折交叉验证
library(rpart)
E0=rep(0,Z);E1=E0
for(i in 1:Z){
  m=mm[[i]]
  n0=n-length(m);n1=length(m)
  a=rpart(Group~.,w[-m,])
  E0[i]=sum(w[-m,1]!=predict(a,w[-m,],type="class"))/n0
  E1[i]=sum(w[m,1]!=predict(a,w[m,],type="class"))/n1
}
mean(E0);mean(E1)

#bagging的3折交叉验证
library(ipred)
set.seed(23451111)
E0=rep(0,Z);E1=E0
for(i in 1:Z){
  m=mm[[i]]
  n0=n-length(m);n1=length(m)
  a=bagging(Group~.,w[-m,])
  E0[i]=sum(w[-m,1]!=predict(a,w[-m,],type="class"))/n0
  E1[i]=sum(w[m,1]!=predict(a,w[m,],type="class"))/n1
}
mean(E0);mean(E1)

#随机森林分类的3折交叉验证
library(randomForest)
set.seed(23451111)
E0=rep(0,Z);E1=E0
for(i in 1:Z){
  m=mm[[i]]
  n0=n-length(m);n1=length(m)
  a=randomForest(Group~.,w[-m,])
  E0[i]=sum(w[-m,1]!=predict(a,w[-m,],type="class"))/n0
  E1[i]=sum(w[m,1]!=predict(a,w[m,],type="class"))/n1
}
mean(E0);mean(E1)

#boosting的3折交叉验证
library(adabag)
set.seed(4410)
E0=rep(0,Z);E1=E0
for(i in 1:Z){
  m=mm[[i]]
  n0=n-length(m);n1=length(m)
  a=boosting(Group~.,w[-m,])
  E0[i]=sum(w[-m,1]!=predict(a,w[-m,])$class)/n0
  E1[i]=sum(w[m,1]!=predict(a,w[m,])$class)/n1
}
mean(E0);mean(E1)

#svm支持向量机的3折交叉验证
library(e1071)
E0=rep(0,Z);E1=E0
for(i in 1:Z){
  m=mm[[i]]
  n0=n-length(m);n1=length(m)
  a=svm(Group~.,w[-m,],kernal="sigmoid")
  E0[i]=sum(w[-m,1]!=predict(a,w[-m,]))/n0
  E1[i]=sum(w[m,1]!=predict(a,w[m,]))/n1
}
mean(E0);mean(E1)



#install.packages("caret")
library(caret)
library(lattice)
library(ggplot2)

#加载数据
dat0 = read.csv("otu.csv", fileEncoding ="UTF-8")
head(dat0[1:6, 1:6])
##数据预处理及数据分割##
##（1）缺失值处理##
nrow(dat0)
dat = na.omit(dat0)
##(2)转换因子...
##(3)数据划分为训练集合测试集##
#设置随机种子
set.seed(1234)
#留出法：将数据集的2/3划分为训练集，1/3分为测试集
trainIndex = createDataPartition(dat$Group, p=2/3,
                                 list = FALSE,
                                 times =1)
#creatDataPartition会自动从y的各个level随机取出等比例的数据来，组成训练集，可以理解为分层抽样；
datTrain = dat[trainIndex, ]
#训练集
datTest = dat[-trainIndex, ]
#全集上因变量各个水平的比例
table(dat$Group)/nrow(dat)
#训练集上因变量各个水平的比例
table(datTrain$Group)/nrow(datTrain) 
#测试集上因变量各个水平的比例
table(datTest$Group)/nrow(datTest) 

##处理0方差变量
#dim(datTrain)
#(nzv =nearZeroVar(datTrain))
#datTrain =datTrain[, -nzv]
#dim(datTrain)

##标准化处理##
preProcValues = preProcess(datTrain, method = c("center", "scale"))
#利用训练集的均值和方差对测试集进行标准化处理
trainTransformed = predict(preProcValues, datTrain)
testTransformed = predict(preProcValues, datTest)

###变量选择###
##封装法rfe：recursive feature selection##
subsets = c(2:20)
#要选择的变量个数
ctrl = rfeControl(functions = rfFuncs, method = "cv")
#首先定义控制参数，functions是确定用什么样的模型进行自变量排序，本实验选择的模型是随机森林
#根据目标函数（通常是预测效果评分），每次选择若干特征
#method是确定用什么样的抽样方法，本实验使用cv，即交叉验证
ctrl

x = trainTransformed[,-which(colnames(trainTransformed) %in% "Group")]
y = trainTransformed[,"Group"]
y=factor(y)
x = x[, -1]
Profile = rfe(x=x, y=y, sizes = subsets, rfeControl = ctrl)
Profile$optVariables


##模型训练及调参##
dat.train = trainTransformed[, c(Profile$optVariables, "Group")]
dat.test = testTransformed[, c(Profile$optVariables, "Group")]
#随机森林#
set.seed(1234)
gbmFit1 = train(Group ~., data = dat.train, method = "rf")
#用于训练模型#
importance = varImp(gbmFit1, scale = FALSE)
#得到各个变量的重要性
plot(importance, xlab = "Importance")
###模型预测及评价###
data.predict = predict(gbmFit1, newdata = dat.test)
confusionMatrix(data.predict, factor(dat.test$Group))
#获得评分#














